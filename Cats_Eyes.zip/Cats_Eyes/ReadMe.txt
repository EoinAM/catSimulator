Author: Eoin Abbey-Maher @Zombi3Whisp3r3r
Website: eoinabbey-maher.weebly.com
Game: Cats Eyes

Description: Explore the Garden as a small cat

The game was made as part of One Game A Month with the Theme being Creature Feature,
And is more of a test demo rather than
a full game, I used this month to learn more about the Unity platform and c#

I also wanted to take some time and play around with Blender to make some 3D models.

----------------------------- Controls -----------------------------
Space: Jump
W: Walk forward
A: Turn Left
D: Turn Right
S: Sit Down